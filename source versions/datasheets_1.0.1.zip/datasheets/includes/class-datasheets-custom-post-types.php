<?php

/** 
 * required in the main includes file.
 * Defines custom post types and how they work
 */
 
 
class Datasheets_Custom_Post_Types {

    public function __construct() {
        add_action( 'init', array( $this, 'register_my_custom_post_types' ) );
    }

    public function register_my_custom_post_types() {
        $template_labels = array(
            'name'                => __( 'Datasheet Templates', 'datasheets' ),
            'singular_name'       => __( 'Datasheet Template', 'datasheets' ),
			'menu_name'           => __( 'Datasheet Templates', 'datasheets' ),
			'parent_item_colon'   => __( 'Parent Datasheet Template', 'datasheets' ),
			'all_items'           => __( 'All Datasheet Templates', 'datasheets' ),
			'view_item'           => __( 'View Datasheet Template', 'datasheets' ),
			'add_new_item'        => __( 'Add New Datasheet Template', 'datasheets' ),
			'add_new'             => __( 'Add New', 'datasheets' ),
			'edit_item'           => __( 'Edit Datasheet Template', 'datasheets' ),
			'update_item'         => __( 'Update Datasheet Template', 'datasheets' ),
			'search_items'        => __( 'Search Datasheet Template', 'datasheets' ),
			'not_found'           => __( 'Not Found', 'datasheets' ),
			'not_found_in_trash'  => __( 'Not found in Trash', 'datasheets' ),
        );

        $template_args = array(
            'label'              => __( 'Datasheet Templates', 'datasheets' ),
			'description'        => __( 'Reusable layout templates for Datasheet PDFs.', 'datasheets' ),
			'labels'             => $template_labels,

            // Features this CPT supports in Post Editor
			'supports'            => array( 'title', 'revisions', 'editor' ),
			// You can associate this CPT with a taxonomy or custom taxonomy. 
			'taxonomies'          => array( 'genres' ),
			/* A hierarchical CPT is like Pages and can have
			* Parent and child items. A non-hierarchical CPT
			* is like Posts.
			*/
			'hierarchical'        => false,
			'public'              => false,
			'publicly_queryable'  => false,
			'show_ui'             => true,
			'show_in_menu'        => 'datasheets',
			'show_in_nav_menus'   => false,
			'show_in_admin_bar'   => true,
			'can_export'          => true,
			'has_archive'         => true,
			'exclude_from_search' => true,
			'rewrite'             => false,
			'publicly_queryable'  => true,
			'capability_type'     => ['post', 'datasheet_template', 'datasheet_templates'],
			// Enable block editor (Gutenberg):
			'show_in_rest'        => true,
			'map_meta_cap'        => true,
        );

        register_post_type( 'datasheet_template', $template_args );
		
		
		
		$datasheet_labels = array(
            'name'               => __( 'Datasheets', 'datasheets' ),
            'singular_name'      => __( 'Datasheet', 'datasheets' ),
			'menu_name'           => __( 'Datasheet', 'datasheets' ),
			'parent_item_colon'   => __( 'Parent Datasheet', 'datasheets' ),
			'all_items'           => __( 'All Datasheets', 'datasheets' ),
			'view_item'           => __( 'View Datasheet', 'datasheets' ),
			'add_new_item'        => __( 'Add New Datasheet', 'datasheets' ),
			'add_new'             => __( 'Add New', 'datasheets' ),
			'edit_item'           => __( 'Edit Datasheet', 'datasheets' ),
			'update_item'         => __( 'Update Datasheet', 'datasheets' ),
			'search_items'        => __( 'Search Datasheet', 'datasheets' ),
			'not_found'           => __( 'Not Found', 'datasheets' ),
			'not_found_in_trash'  => __( 'Not found in Trash', 'datasheets' ),
        );

        $datasheet_args = array(
            'label'              => __( 'Datasheet', 'datasheets' ),
			'description'        => __( 'Datasheets', 'datasheets' ),
			'labels'             => $datasheet_labels,
            // Features this CPT supports in Post Editor
			'supports'            => array( 'title', 'revisions', 'editor' ),
			// You can associate this CPT with a taxonomy or custom taxonomy. 
			'taxonomies'          => array( 'genres' ),
			/* A hierarchical CPT is like Pages and can have
			* Parent and child items. A non-hierarchical CPT
			* is like Posts.
			*/
			'hierarchical'        => false,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => 'datasheets',
			'show_in_nav_menus'   => false,
			'show_in_admin_bar'   => true,
			'can_export'          => true,
			'has_archive'         => true,
			'exclude_from_search' => true,
			'publicly_queryable'  => true,
			'capability_type'     => 'post',
			// Enable block editor (Gutenberg):
			'show_in_rest' => true,
        );

        register_post_type( 'datasheet', $datasheet_args );
		
		
    }
}



