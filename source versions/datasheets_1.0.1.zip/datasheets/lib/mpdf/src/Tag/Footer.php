<?php

namespace Mpdf\Tag;

class Footer extends BlockTag
{


}
